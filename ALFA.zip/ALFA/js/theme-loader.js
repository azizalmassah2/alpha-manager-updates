/**
 * theme-loader.js
 * Reads themeHue/themeS/themeL from siteConfig.
 * Uses <style id="st1"> slot AND appends a high-specificity override after all CSS loads.
 */
(function () {
  function buildCSS(hue, sat, lit) {
    var lDark  = Math.max(lit - 12, 20);
    var lLight = Math.min(lit + 12, 85);
    var secH   = (hue + 140) % 360;
    var secS   = Math.max(sat - 15, 40);
    var secL   = Math.max(lit - 21, 30);

    // Use :root:root (double pseudo-class) for higher specificity than plain :root
    // This beats any :root rule in external CSS files
    return ':root:root{' +
      '--primary:'         + hue  + ' ' + sat  + '% ' + lit              + '%;' +
      '--primary-light:'   + hue  + ' ' + sat  + '% ' + lLight           + '%;' +
      '--primary-dark:'    + hue  + ' ' + sat  + '% ' + lDark            + '%;' +
      '--primary-glow:'    + hue  + ' ' + sat  + '% ' + lit              + '%/.25;' +
      '--text-accent:'     + hue  + ' ' + sat  + '% ' + lit              + '%;' +
      '--secondary:'       + secH + ' ' + secS + '% ' + secL             + '%;' +
      '--secondary-light:' + secH + ' ' + secS + '% ' + Math.min(secL+13,65) + '%;' +
      '--secondary-dark:'  + secH + ' ' + secS + '% ' + Math.max(secL-11,15) + '%;' +
      '--shadow-button:0 4px 20px hsl(' + hue + ' ' + sat + '% ' + lit + '%/.35);' +
    '}';
  }

  function applyTheme() {
    var cfg = window.siteConfig || {};
    var hue = cfg.themeHue !== undefined ? Number(cfg.themeHue) : 217;
    var sat = cfg.themeS   !== undefined ? Number(cfg.themeS)   : 91;
    var lit = cfg.themeL   !== undefined ? Number(cfg.themeL)   : 60;

    var css = buildCSS(hue, sat, lit);

    // Write into st1 (present in hotspot pages - loaded before external CSS)
    var st1 = document.getElementById('st1');
    if (st1) st1.textContent = css;

    // Also append a SEPARATE tag at end of <head> so it comes AFTER index.min.css
    var tag = document.getElementById('__theme_late__');
    if (!tag) {
      tag = document.createElement('style');
      tag.id = '__theme_late__';
      var head = document.head || document.getElementsByTagName('head')[0];
      if (head) head.appendChild(tag);
    }
    tag.textContent = css;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyTheme);
  } else {
    applyTheme();
  }

  // Re-apply after full load (catches any async stylesheet injections)
  window.addEventListener('load', applyTheme);
})();
