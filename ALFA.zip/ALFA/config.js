window.siteConfig = {
  "siteName": "◉ ألفّا بلاس ◉",
  "welcomeMessage": "مرحبا بكم في شبكة الفا لخدمات الانترنت",
  "welcomeMessageV": false,
  "erbV": false,
  "textSlider1": "{ قل للمؤمنين يغضوا من أبصارهم ويحفظوا فروجهم ذلك أزكى لهم إن الله خبير بما يصنعون }(النور:30)",
  "speedOptions": [
    {
      "value": "",
      "label": "كرت هوتسبوت",
      "selected": false
    },
    {
      "value": "2M/2M",
      "label": "سرعة اقتصادية",
      "selected": false
    },
    {
      "value": "4M/4M",
      "label": "سرعة عادية",
      "selected": false
    },
    {
      "value": "4M/8M",
      "label": "سرعة متوسطة",
      "selected": false
    },
    {
      "value": "4M/16M",
      "label": "سرعة عالية",
      "selected": true
    }
  ],
  "imageCount": "0",
  "imageV": false,
  "packages": [
    
    {
      "vl": "يوم",
      "time": "3 ساعات",
      "size": "400 ميجا",
      "price": "100 ريال"
    },
    {
      "vl": "3 أيام",
      "time": "6 ساعات",
      "size": "1 جيجا",
      "price": "200 ريال"
    },
    {
      "vl": "8 أيام",
      "time": "8 ساعة",
      "size": "1.5 جيجا",
      "price": "300 ريال"
    },
    {
      "vl": "12 أيام",
      "time": "20 ساعة",
      "size": "3 جيجا",
      "price": "500 ريال"
    },
    {
      "vl": "باقة 7 يوم",
      "time": "45 ساعة",
      "size": "6 جيجا",
      "price": "1000 ريال"
    },
    {
      "vl": "شهري",
      "time": "مفتوح",
      "size": "16 جيجا",
      "price": "3000 ريال"
    },
    {
      "vl": "شهري",
      "time": "شهري",
      "size": "35 جيجا",
      "price": "5000 ريال"
    },
    {
      "vl": "شهري",
      "time": "شهري",
      "size": "75 جيجا",
      "price": "10000 ريال"
    },
    {
      "vl": "برود باند",
      "time": "شهري",
      "size": "120 جيجا",
      "price": "10000 ريال"
    }

  ],
  "offers": "لا توجد عروض حاليا",
  "salesPoints": [
"الزباء - بقالة وجدي",
"موبقة - زياد التاهوسا",
"بني عمر الجبل - بقالة بلال"
  ],
  "estr": "",
  "moba": "",
  "supportPhone": "",
  "developerName": "م/ عزيز المساح",
  "developerPhone": "771122633",
  "activeTheme": "sakura"
};
