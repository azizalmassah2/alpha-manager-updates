
(function(){
  var newCardInserted = false;

  function getConfig(key, fallback) {
    try { return (window.siteConfig && window.siteConfig[key]) || fallback; }
    catch(e) { return fallback; }
  }

  function buildCard() {
    var phone    = getConfig('supportPhone', ' ');
    var devName  = getConfig('developerName', 'م/ عزيز المساح');
    var devPhone = getConfig('developerPhone', '0');

    var card = document.createElement('div');
    card.id = 'aziz-dev-card';
    card.innerHTML =
      '<div style="margin: 20px auto 10px; max-width: 400px; display: flex; flex-direction: column; gap: 8px; font-family: inherit;">' +
        
        /* ── Support Card ── */
        '<div class="glass-premium hover-lift" style="' +
          'display: flex; align-items: center; justify-content: space-between; ' +
          'padding: 16px 20px; border-radius: 20px; ' +
          'box-shadow: 0 8px 30px rgba(0,0,0,0.05);' +
        '">' +
          '<div style="display: flex; align-items: center; gap: 14px;">' +
            '<div style="' +
              'width: 46px; height: 46px; border-radius: 50%; ' +
              'background: var(--primary, #3b82f6); color: var(--primary-foreground, #fff); ' +
              'display: flex; align-items: center; justify-content: center; ' +
              'box-shadow: 0 6px 16px rgba(0,0,0,0.15); flex-shrink: 0;' +
            '">' +
              '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>' +
            '</div>' +
            '<div>' +
              '<div style="font-size: 11px; color: var(--foreground); opacity: 0.65; font-weight: 700; margin-bottom: 2px; letter-spacing: 0.5px;">خدمة العملاء والدعم الفني</div>' +
              '<div style="font-size: 18px; font-weight: 900; color: var(--foreground); letter-spacing: 1.5px; direction: ltr;">' + phone + '</div>' +
            '</div>' +
          '</div>' +
          '<a href="tel:' + phone + '" style="' +
            'background: var(--primary, #3b82f6); color: var(--primary-foreground, #fff); ' +
            'text-decoration: none; padding: 8px 16px; border-radius: 24px; ' +
            'font-size: 13px; font-weight: 800; box-shadow: 0 4px 12px rgba(0,0,0,0.1); ' +
            'display: flex; align-items: center; gap: 6px; transition: transform 0.2s;' +
          '">' +
            'اتصال' +
          '</a>' +
        '</div>' +

        /* ── Developer Badge (Pill) ── */
        '<div style="display: flex; justify-content: center; margin-top: 2px;">' +
          '<a href="tel:' + devPhone + '" class="hover-lift" style="' +
            'display: inline-flex; align-items: center; gap: 12px; ' +
            'background: var(--card-bg, #fff); border: 1px solid rgba(128,128,128,0.15); ' +
            'padding: 6px 14px 6px 16px; border-radius: 50px; text-decoration: none; ' +
            'color: var(--foreground, #000); box-shadow: 0 4px 15px rgba(0,0,0,0.06); ' +
            'opacity: 0.95;' +
          '">' +
            '<div style="display: flex; align-items: center; gap: 6px; border-left: 1px solid rgba(128,128,128,0.2); padding-left: 12px;">' +
              '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--primary, #3b82f6)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path></svg>' +
              '<div style="font-size: 11.5px; font-weight: 700;">برمجة: <span style="font-weight: 900;">' + devName + '</span></div>' +
            '</div>' +
            '<div style="display: flex; align-items: center; gap: 5px;">' +
              '<div style="font-size: 13px; font-weight: 800; direction: ltr; letter-spacing: 0.5px;">' + devPhone + '</div>' +
              '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--primary, #3b82f6)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>' +
            '</div>' +
          '</a>' +
        '</div>' +

      '</div>';
    return card;
  }

  function processNode(node) {
    if (!node || node.nodeType !== 1) return;
    if (node.id === 'aziz-dev-card') return;

    var txt = node.innerText || node.textContent || '';
    
    // 1. Hide original developer section and inject ours
    if (
      (txt.indexOf('770936309') !== -1 || txt.indexOf('774758658') !== -1 || txt.indexOf('\u0623\u062d\u0645\u062f \u0631\u0627\u0626\u062f') !== -1)
      && txt.indexOf('\u0628\u0631\u0645\u062c\u0629') !== -1
    ) {
      node.style.setProperty('display',        'none',     'important');
      node.style.setProperty('visibility',     'hidden',   'important');
      node.style.setProperty('height',         '0',        'important');
      node.style.setProperty('overflow',       'hidden',   'important');
      node.style.setProperty('position',       'absolute', 'important');
      node.style.setProperty('pointer-events', 'none',     'important');

      if (!newCardInserted && !document.getElementById('aziz-dev-card')) {
        newCardInserted = true;
        var card = buildCard();
        if (node.parentNode) {
          node.parentNode.insertBefore(card, node.nextSibling);
        }
      }
    }

    // 2. Fix dead "التواصل مع الدعم" buttons in status/index pages
    if (node.tagName === 'BUTTON' && txt.indexOf('\u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u062f\u0639\u0645') !== -1 && !node.hasAttribute('data-fixed-phone')) {
      var phone = getConfig('supportPhone', '776304602');
      var a = document.createElement('a');
      a.className = node.className;
      a.innerHTML = node.innerHTML;
      a.setAttribute('data-fixed-phone', 'true');
      a.href = 'https://wa.me/967' + phone.replace(/^\+?967/, '');
      a.style.textDecoration = 'none';
      a.style.display = 'inline-flex';
      a.onclick = function(e) { e.stopPropagation(); };
      if (node.parentNode) {
        node.parentNode.replaceChild(a, node);
      }
    };
    }
  }

  var observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(m) {
      m.addedNodes.forEach(function(node) {
        processNode(node);
        if (node.querySelectorAll) {
          var all = node.querySelectorAll('*');
          for (var i = 0; i < all.length; i++) processNode(all[i]);
        }
      });
    });
  });

  observer.observe(document.documentElement, {childList: true, subtree: true});
})();
