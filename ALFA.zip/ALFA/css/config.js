window.siteConfig = {
  "siteName": "ألفا لخدمات الأنترنت",
  "welcomeMessage": "مرحبا بكم في شبكة الفا بلاس",
  "welcomeMessageV": false,
  "erbV": false,
  "textSlider1": "{ قل للمؤمنين يغضوا من أبصارهم ويحفظوا فروجهم ذلك أزكى لهم إن الله خبير بما يصنعون }(النور:30)",
  "speedOptions": [
    {
      "value": "",
      "label": "كرت هوتسبوت",
      "selected": false
    },
    {
      "value": "2M/2M",
      "label": "سرعة اقتصادية",
      "selected": false
    },
    {
      "value": "4M/4M",
      "label": "سرعة عادية",
      "selected": false
    },
    {
      "value": "4M/8M",
      "label": "سرعة متوسطة",
      "selected": false
    },
    {
      "value": "4M/16M",
      "label": "سرعة عالية",
      "selected": true
    }
  ],
  "imageCount": "0",
  "imageV": false,
  "packages": [
    {
      "vl": "باقة 3 ايام",
      "time": "7 ساعات",
      "size": "750 ميجا",
      "price": "200 ريال"
    },
    {
      "vl": "باقة 5 ايام",
      "time": "10 ساعة",
      "size": "1 جيجا",
      "price": "300 ريال"
    },
    {
      "vl": "باقة 7 يوم",
      "time": "20 ساعة",
      "size": "2 جيجا",
      "price": "500 ريال"
    }
  ],
  "offers": "قريباً",
  "salesPoints": [
    "جميع البقالات المجاورة للشبكة"
  ],
  "estr": "",
  "moba": "",
  "supportPhone": "",
  "developerName": "م/ عزيز المساح",
  "developerPhone": "777777777",
  "activeTheme": "sakura"
};
